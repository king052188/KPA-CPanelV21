<?php namespace App;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class MemberBasic extends \Eloquent {
    protected $table = 'member_basic_table';
}
