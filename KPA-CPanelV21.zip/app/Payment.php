<?php namespace App;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class Payment extends \Eloquent {
    protected $table = 'payment_table';
}
