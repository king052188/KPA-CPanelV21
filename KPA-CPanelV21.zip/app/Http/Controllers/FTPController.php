<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FTPController extends Controller
{
    //
}
