<?php namespace App;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class MySQLAccount extends \Eloquent {
    protected $table = 'mysql_account_table';
}
